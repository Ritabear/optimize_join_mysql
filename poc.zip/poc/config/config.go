package config

const USERNAME    string  = "root"
const PASSWORD    string  = "C@JVUqe!p!Yin4XBWwmexwzodpiVziuhB.T!NbEJ8_@RdUp3"
const ADDR        string  = "127.0.0.1"
const PORT        int     = 3306
const DEMO1_DB    string  = "malexp"
